from telethon import *
import datetime as DT
import requests, time, os, subprocess, re, sqlite3, sys, random, base64, json, math
import logging

logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

# load var.txt
exec(open("/usr/bin/public/var.txt", "r").read())

# inisialisasi bot
bot = TelegramClient("ddsdswl", "6", "eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)

# setup database admin
try:
    open("/usr/bin/public/database.db")
except:
    x = sqlite3.connect("/usr/bin/public/database.db")
    c = x.cursor()
    c.execute("CREATE TABLE admin (user_id)")

    # ADMIN diambil dari var.txt, bisa banyak ID dipisah spasi
    admin_ids = ADMIN.split()

    for admin_id in admin_ids:
        c.execute("INSERT INTO admin (user_id) VALUES (?)", (admin_id,))

    x.commit()

# fungsi untuk koneksi db
def get_db():
    x = sqlite3.connect("/usr/bin/public/database.db")
    x.row_factory = sqlite3.Row
    return x

# cek apakah user_id admin
def valid(user_id):
    x = get_db()
    c = x.cursor()
    c.execute("SELECT 1 FROM admin WHERE user_id = ?", (str(user_id),))
    return c.fetchone() is not None

# fungsi utilitas
def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])
