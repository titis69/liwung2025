from public import *
import asyncio
import subprocess
from telethon import Button, events

# Fungsi animasi loading titik-titik
async def animate_loading(message, text, repeat=3):
    """Animasi loading dengan titik-titik bergerak"""
    for _ in range(repeat):
        for dots in [f"⏳ {text}.", f"⏳ {text}..", f"⏳ {text}..."]:
            await message.edit(dots)
            await asyncio.sleep(0.5)
    return message

# CEK VPS - TANPA VALIDASI USER ID
@bot.on(events.CallbackQuery(data=b'info'))
async def info_vps(event):
    cmd = 'bot-vps-info'.strip()

    # Loading titik-titik
    await animate_loading(event, "Processing")

    # Loading tambahan sebelum hasil
    await event.edit("⏳ Wait.. Setting up Server Data")
    await asyncio.sleep(1)

    # Menjalankan perintah VPS
    try:
        output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
        await event.respond(
            f"```{output}```\n**🤖@frel01**",
            buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
        )
    except subprocess.CalledProcessError as e:
        await event.respond(f"Error:\n```{e.output}```")
    except Exception as e:
        await event.respond(f"Unexpected error:\n```{str(e)}```")